<?php

namespace App\Http\Controllers\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;


class AuthController extends Controller
{
    public function ShowRegister()
    {
        return view('auth.register');
    } public function register(Request $request)
    {
         // Determine registration type based on which input is present
    if ($request->has('phone')) {
        // Phone registration
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'phone' => 'required|digits:10|unique:users,phone',
            'password' => 'required|min:6',
            'repassword' => 'required|same:password',
        ]);
    } elseif ($request->has('email')) {
        // Email registration
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'repassword' => 'required|same:password',
        ]);
    } else {
        return redirect()->back()
            ->withErrors(['form' => 'Invalid form submission.'])
            ->withInput();
    }

    // Handle validation failure
    if ($validator->fails()) {
        return redirect()->back()
            ->withErrors($validator)
            ->withInput();
    }

    // Create the user
    $user = new User();
    $user->name = $request->name;

    if ($request->has('phone')) {
        $user->phone = $request->phone;
    } else {
        $user->email = $request->email;
    }

    $user->password = Hash::make($request->password);
    $user->save();

    // Log user in or redirect
    auth()->login($user);

    return redirect()->url('/dashboard'); // Change to your post-registration route
    }
   public function login(Request $request)
    {
        $user = User::where('email', $request->login)
            ->orWhere('phone', $request->login)
            ->first();
        if (!$user) {
            return redirect()->back()
                ->withErrors(['login' => 'User not found.'])
                ->withInput();
        }else if (!$user->is_active) {
            return redirect()->back()
                ->withErrors(['login' => 'Your account is inactive. Please contact support.'])
                ->withInput();
        }
        $credentials = $request->only('login', 'password');

        // Determine if login is by phone or email
        if (is_numeric($credentials['login']) && strlen($credentials['login']) == 10) {
            // Phone login
            $credentials['phone'] = $credentials['login'];
            unset($credentials['login']);
        } else {
            // Email login
            $credentials['email'] = $credentials['login'];
            unset($credentials['login']);
        }

        if (auth()->attempt($credentials)) {
            return redirect()->to('/dashboard'); // Change to your post-login route
        }

        return redirect()->back()
            ->withErrors(['login' => 'Invalid credentials.'])
            ->withInput();
    } 
    public function resetpassword()
    {
        return view('auth.resetpassword');
    }
 
    public function resetpasswordpost(Request $request)
{
    $request->validate([
        'login' => 'required',
        'password' => 'required|min:6',
        'repassword' => 'required|same:password',
    ]);

    $login = $request->input('login');
    $field = filter_var($login, FILTER_VALIDATE_EMAIL) ? 'email' : 'phone';

    $user = \App\Models\User::where($field, $login)->first();

    if (!$user) {
        return redirect()->back()->withErrors([
            'login' => 'User not found with given ' . $field,
        ])->withInput()
        ->with('active_tab', $inputType);
        
    }

    $user->password = Hash::make($request->input('password'));
    $user->save();

    return redirect()->back()->with('status', 'Password successfully updated.');
}

    function logout()
{
    Auth::logout();

    // Invalidate the session
    request()->session()->invalidate();

    // ✨ CRITICAL: Regenerate the CSRF token after invalidating the session
    // This ensures a fresh token is available for the next page load (e.g., login)
    request()->session()->regenerateToken();

    Session::flush(); // This clears all session data

    // Redirect to the login page with a success message
    return redirect('/')->with('status', 'You have been logged out successfully.');
}
}
