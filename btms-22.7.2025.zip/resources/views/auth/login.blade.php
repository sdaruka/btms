@extends('layouts.main')

@section('title', 'Login')

@section('content')
<div class="container d-flex justify-content-center align-items-center" style="min-height: 90vh;">
    <div class="card shadow-lg border-0" style="max-width: 420px; width: 100%;">
        <div class="card-body p-4" x-data="{ activeTab: '{{ session('active_tab', 'phone') }}' }">
            <div class="text-center mb-4">
                <img src="{{ asset('images/logo.png') }}" alt="Logo" style="height: 50px;">
                <h4 class="mt-3 fw-bold text-dark">Login to Bhumis</h4>
            </div>

            @if (Session::has('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    {{ Session::get('error') }}
                    <button type="button" class="btn-close" @click="$el.remove()"></button>
                </div>
            @endif

            <!-- Alpine Tabs -->
            <div class="nav nav-tabs nav-justified mb-3" role="tablist">
                <button
                    class="nav-link"
                    :class="activeTab === 'phone' ? 'active' : ''"
                    @click="activeTab = 'phone'"
                    type="button"
                    role="tab"
                >Phone</button>
                <button
                    class="nav-link"
                    :class="activeTab === 'email' ? 'active' : ''"
                    @click="activeTab = 'email'"
                    type="button"
                    role="tab"
                >Email</button>
            </div>

            <!-- Tab Content -->
            <div>
                <!-- Phone Tab -->
                <div x-show="activeTab === 'phone'" x-transition role="tabpanel">
                    <form method="POST" action="{{ url('/login') }}">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" name="login" autofocus autocomplete="tel-country-code" class="form-control" placeholder="10-digit number" maxlength="10" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" autocomplete="current-password" class="form-control" required>
                        </div>
                        <button class="btn btn-danger w-100">Login with Phone</button>
                    </form>
                </div>

                <!-- Email Tab -->
                <div x-show="activeTab === 'email'" x-transition role="tabpanel">
                    <form method="POST" action="{{ url('/login') }}">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="login" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button class="btn btn-danger w-100">Login with Email</button>
                    </form>
                </div>
            </div>

            <div class="d-flex justify-content-between mt-3">
                <a href="{{ url('/showregister') }}" class="text-decoration-none">Register</a>
                <a href="{{ url('/resetpassword') }}" class="text-decoration-none">Forgot Password?</a>
            </div>
        </div>
    </div>
</div>
@endsection