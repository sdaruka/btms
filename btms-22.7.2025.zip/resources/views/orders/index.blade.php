@extends('layouts.main')
@section('title', 'Orders')
@section('content')
    <div class="container">
        <div class="row mb-4 g-2 align-items-center">

            <div class="col-12 col-md-4">
                <h2 class="fw-bold mb-0">Orders</h2>
            </div>

            <div class="col-12 col-md-4">
                <form action="{{ route('orders.index') }}" method="GET" class="d-flex">
                    <input type="text" name="search" value="{{ request('search') }}" class="form-control me-2"
                        placeholder="Search by customer name or order numer">
                    <input type="date" name="search_date" class="form-control" />

                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-search"></i>
                    </button>
                </form>
            </div>
            <div class="col-12 col-md-4 text-md-end">
                @if (auth()->user()->role == 'admin' || auth()->user()->role == 'staff')
                    <a href="{{ route('orders.create') }}" class="btn btn-warning">
                        <i class="fa-solid fa-boxes-stacked me-2"></i>New Order</a>
                @endif
            </div>
        </div>

    </div>

    @if ($orders->count())
        <div class="table-responsive">
            <table class="table table-striped table-sm ">
                <thead>
                    <tr>
                        <th>#</th>
                        {{-- <th>O. No.</th> --}}
                        <th>Customer </th>
                        {{-- <th>Order Date</th> --}}
                        <th>Delivery</th>
                        @if(auth()->user()->role == 'admin' || auth()->user()->role == 'staff')
                        <th>Total</th>    
                            @endif
                        
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($orders as $order)
                        @php
                            $isOverdue =
                                \Carbon\Carbon::parse($order->delivery_date)->isPast() &&
                                $order->status !== 'Completed';
                        @endphp

                        <tr @if ($isOverdue) class="table-warning" @endif>
                            <td>{{ $loop->iteration + ($orders->currentPage() - 1) * $orders->perPage() }}</td>
                            {{-- <td class="text-center">{{ $order->order_number }}</td> --}}
                            <td><a href="{{ route('orders.show', $order) }}">
                                @if ($order->user->role != 'admin' && $order->user->role != 'staff')
                                    {{ $order->user->name }}
                                @else
                                    {{ $order->user->name }} | {{ $order->user->phone }}</td></a>
                                
                                @endif
                                    {{-- <td>{{ \Carbon\Carbon::parse( $order->order_date)->format('d M Y') }}</td> --}}
                            <td>{{ \Carbon\Carbon::parse($order->delivery_date)->format('d M Y') }}</td>
                        @if(auth()->user()->role == 'admin' || auth()->user()->role == 'staff')
                            
                            <td>₹{{ $order->total_amount }}</td>
                            @endif
                            <td style="position: absolute;">
                                <div class="dropdown" x-data="{ status: '{{ $order->status }}' }">
                                    <button type="button" class="badge dropdown-toggle" data-bs-toggle="dropdown"
                                        aria-expanded="false" style="cursor: pointer; border: none;"
                                        :class="{
                                            'bg-primary': status === 'Assigned',
                                            'bg-info': status === 'Completed',
                                            'bg-warning': status === 'Pending',
                                            'bg-danger': status === 'Cancelled',
                                            'bg-dark': status === 'Alteration',
                                            'bg-success': status === 'Delivered',
                                            'bg-light text-info': status === 'In Progress',
                                            'bg-secondary': ![
                                                'Assigned', 'Pending', 'Completed', 'Cancelled',
                                                'Alteration', 'Delivered', 'In Progress'
                                            ].includes(status)
                                        }"
                                        x-text="status">
                                    </button>

                                    <ul class="dropdown-menu">
                                        @if (auth()->user()->role == 'admin' || auth()->user()->role == 'staff')
                                            @foreach (['Assigned', 'Pending', 'Completed', 'Cancelled', 'Alteration', 'Delivered', 'In Progress'] as $s)
                                                <li>
                                                    <button type="button" class="dropdown-item"
                                                        @click="
                                                            fetch('{{ route('orders.updateStatus', $order) }}', {
                                                                method: 'PATCH',
                                                                headers: {
                                                                    'Content-Type': 'application/json',
                                                                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                                                                },
                                                                body: JSON.stringify({ status: '{{ $s }}' })
                                                            }).then(res => res.ok && (status = '{{ $s }}'))
                                                        ">
                                                        {{ $s }}
                                                    </button>
                                                </li>
                                            @endforeach
                                        @else
                                            @foreach (['Assigned', 'Completed', 'In Progress'] as $s)
                                                <li>
                                                    <button type="button" class="dropdown-item"
                                                        @click="
                                                            fetch('{{ route('orders.updateStatus', $order) }}', {
                                                                method: 'PATCH',
                                                                headers: {
                                                                    'Content-Type': 'application/json',
                                                                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                                                                },
                                                                body: JSON.stringify({ status: '{{ $s }}' })
                                                            }).then(res => res.ok && (status = '{{ $s }}'))
                                                        ">
                                                        {{ $s }}
                                                    </button>
                                                </li>
                                            @endforeach
                                        @endif


                                    </ul>
                                </div>
                            </td>
                            <td >
                                <div class="position-absolute">
                                    <div class="dropdown ms-3">
                                        <button class="btn btn-sm " type="button" data-bs-toggle="dropdown">
                                            <i class="fa fa-ellipsis-vertical"></i>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item text-primary" style="cursor: pointer"
                                                    href="{{ route('orders.print', $order) }}">
                                                    <i class="fa fa-print me-2 text-primary"></i>Print</a>
                                            </li>
                                            <li><a class="dropdown-item text-info"
                                                    href="{{ route('orders.show', $order) }}">
                                                    <i class="fa fa-eye me-2 text-info"></i>View</a>
                                            </li>
                                            @if (auth()->user()->role == 'admin' || auth()->user()->role == 'staff')
                                                <li><a class="dropdown-item text-warning"
                                                        href="{{ route('orders.edit', $order) }}">
                                                        <i class="fa fa-edit me-2 text-warning"></i>Edit</a>
                                                </li>

                                                <li>
                                                    <form action="{{ route('orders.destroy', $order) }}" method="POST"
                                                        onsubmit="return confirm('Delete this order?')">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="dropdown-item text-danger">
                                                            <i class="fa fa-trash me-2 text-danger"></i> Delete</button>
                                                    </form>
                                                </li>
                                            @endif
                                            <li><a class="dropdown-item text-success" style="cursor: pointer"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#assignModal{{ $order->id }}">
                                                    <i class="fa-solid fa-people-arrows me-2 text-success"></i> Assign
                                                    To</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        {{ $orders->links('pagination::bootstrap-5') }}
    @else
        <div class="alert alert-info">No orders found.</div>
    @endif
    </div>
    {{-- @include('orders.assign'); --}}
    @foreach ($orders as $order)
        <!-- Dropdown trigger -->
        @include('orders.assign', ['order' => $order, 'tailors' => $tailors])
    @endforeach
@endsection
