{{-- Customer & Delivery --}}
            <div class="row mb-4 bg-dark text-white p-2 rounded">
                <div class="col-md-3 mb-3">
                    <label class="form-label">Customer</label>
                    <div class="input-group">
                        <select x-model="selectedUserId" @change="fetchPreviousMeasurements()" name="user_id"
                            class="form-select">
                            <option value="">Select customer</option>
                            <template x-for="cust in customers" :key="cust.id">
                                <option :value="String(cust.id)" x-text="`${cust.name} (${cust.phone})`"></option>
                            </template>
                        </select>

                        <span class="input-group-text bg-danger text-white cursor-pointer" @click="showModal = true">
                            <i class="fas fa-user-plus"></i>
                        </span>

                        <!-- Modal -->
                        <div x-show="showModal" class="modal-backdrop"
                            style="position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.5);">
                            <template x-if="customerErrorMessage">
                                <div class="text-danger small mt-2" x-text="customerErrorMessage"></div>
                            </template>
                            <div class="modal-content"
                                style="background: white; padding: 1rem; margin: 10% auto; width: 300px;">
                                <h5>Add New Customer</h5>
                                <input type="text" x-model="newCustomer.name" placeholder="Customer Name"
                                    class="form-control mb-2">
                                <input type="text" x-model="newCustomer.phone" placeholder="Phone"
                                    class="form-control mb-2">
                                <div class="d-flex justify-content-end">
                                    <button class="btn btn-secondary me-2" @click="showModal = false">Cancel</button>
                                    <button class="btn btn-primary" @click="createCustomer()">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    @error('user_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Order Date</label>
                    <input type="date" name="order_date" class="form-control @error('Order_date') is-invalid @enderror"
                        value="{{ old('order_date', now()->format('Y-m-d')) }}" readonly>
                    @error('order_date')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Delivery Date</label>
                    <input type="date" name="delivery_date"
                        class="form-control @error('delivery_date') is-invalid @enderror"
                        value="{{ old('delivery_date', now()->addDays(10)->format('Y-m-d')) }}">
                    @error('delivery_date')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                 

                <div class="col-md-3 mb-3">
                    <label class="form-label">Order Number</label>
                    <input type="number" name="order_number"
                        class="form-control @error('order_number') is-invalid @enderror" value="{{ $invoiceNumber }}"
                        readonly>
                    @error('order_number')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>