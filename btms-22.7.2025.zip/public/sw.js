
const cacheName = 'btms-cache-v1.02';
const resourcesToCache = [
    '/',
    
    '/images/logo.png',
    '/offline.html',
    '/css/style.css',
    '/images/icons/icon-192x192.png',
    '/images/icons/icon-512x512.png',
    '/images/images/screenshots/dashboard.png',
];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(cacheName).then(cache => cache.addAll(resourcesToCache))
    );
});

self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request).then(response => {
            return response || fetch(event.request).catch(() => caches.match('/offline.html'));
        })
    );
});

self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.filter(name => name !== cacheName).map(name => caches.delete(name))
            );
        })
    );
});
