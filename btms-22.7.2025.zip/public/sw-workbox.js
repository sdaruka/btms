// sw-workbox.js
importScripts('https://storage.googleapis.com/workbox-cdn/releases/6.5.4/workbox-sw.js');

workbox.precaching.precacheAndRoute([
    { url: '/btms/', revision: null },
    { url: '/btms/offline.html', revision: null },
    { url: '/btms/css/style.css', revision: null },
    { url: '/btms/js/script.js', revision: null },
    { url: '/btms/images/logo.png', revision: null },
    { url: '/btms/images/icons/icon-192x192.png', revision: null },
    { url: '/btms/images/icons/icon-512x512.png', revision: null },
    { url: '/btms/images/screenshots/dashboard.png', revision: null },
]);

workbox.routing.registerRoute(
    ({ request }) => request.destination === 'script' || request.destination === 'style',
    new workbox.strategies.StaleWhileRevalidate()
);

workbox.routing.registerRoute(
    ({ request }) => request.mode === 'navigate',
    new workbox.strategies.NetworkFirst({
        cacheName: 'pages-cache',
        fallback: '/btms/offline.html',
    })
);