

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Profile Details</h2>
            <a href="<?php echo e(route('profile.edit', ['id' => $user->id])); ?>" class="btn btn-warning">
                <i class="fa-solid fa-pen-to-square me-1"></i> Edit Profile
            </a>
        </div>

        <div class="card shadow-sm p-3">
            <div class="d-flex align-items-center mb-3 gap-4">
                <img src="<?php echo e($user->profile_picture ? asset($user->profile_picture) : asset('images/default-user.svg')); ?>"
                    alt="Profile Picture" class="rounded-circle shadow" width="80" height="80">
                <div>
                    <h5 class="mb-1"><?php echo e($user->name); ?></h5>
                    <p class="mb-0 text-muted"><?php echo e($user->email); ?></p>
                    <p class="mb-0 text-muted"><?php echo e($user->phone); ?></p>
                    <?php if($user->is_active == 1): ?>
                        <p class="mb-0 badge bg-success">Active</p>
                    <?php else: ?>
                        <p class="mb-0 badge bg-secondary">Inactive</p>
                    <?php endif; ?>
                </div>
            </div>

            <hr>

            <p><strong>Role:</strong> <?php echo e(ucfirst($user->role)); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views/profile/show.blade.php ENDPATH**/ ?>