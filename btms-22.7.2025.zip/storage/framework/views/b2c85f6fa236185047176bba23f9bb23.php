
<?php $__env->startSection('title', 'New Order'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-4">Place New Order</h2>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($msg); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php if(session('status')): ?>
            <div class="alert alert-info"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('orders.store')); ?>" method="POST" enctype="multipart/form-data" x-data="orderForm(false)"
            x-init="init()" @submit.prevent="submitForm()" @submit.prevent="createCustomer()">
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('orders.partial.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <?php echo $__env->make('orders.partial.items', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('products.product-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('orders.partial.invoice', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>
    <button type="submit" class="btn btn-danger w-100">
        <i class="fa fa-save"></i>
        Place Order</button>
    

    </form>
    
    <img x-show="hoveredPreview" :src="hoveredPreview" class="thumb-preview"
        @mousemove="(e) => {
         $el.style.left = (e.pageX + 20) + 'px';
         $el.style.top = (e.pageY + 20) + 'px';
     }"
        @mouseleave="hoveredPreview = null">
    <?php echo $__env->make('orders.partial.alpine', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views/orders/create.blade.php ENDPATH**/ ?>