
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold mb-0">Edit Product</h2>
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-warning">
            <i class="fa fa-backward-step me-1"></i> Back
        </a>
    </div>

    <form action="<?php echo e(route('products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        

        
        <div class="mb-3">
            <label class="form-label">Product Name</label>
            <input type="text" name="name" value="<?php echo e(old('name', $product->name)); ?>"
                   class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control"><?php echo e(old('description', $product->description)); ?></textarea>
        </div>

        
        <div class="mb-3">
            <label class="form-label">Measurements Required</label>
            <?php $__currentLoopData = $measurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input class="form-check-input"
                           type="checkbox"
                           name="measurement_ids[]"
                           value="<?php echo e($measurement->id); ?>"
                           <?php echo e(in_array($measurement->id, $product->measurements->pluck('id')->toArray()) ? 'checked' : ''); ?>>
                    <label class="form-check-label"><?php echo e($measurement->name); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="mb-3">
            <label class="form-label">New Rate (optional)</label>
            <input type="number" name="rate" class="form-control" placeholder="e.g. 750">
        </div>
        <div class="mb-3">
            <label class="form-label">Effective Date</label>
            <input type="date" name="effective_date" class="form-control" value="<?php echo e(today()->format('Y-m-d')); ?>">
        </div>

        
        <div class="mb-3">
            <label class="form-label">Upload More Designs</label>
            <input type="file" name="images[]" class="form-control" multiple accept="image/*">
        </div>

        <button type="submit" class="btn btn-success w-100">
            <i class="fa fa-save me-1"></i> Update Product
        </button>
    </form>

    
    <?php if($product->designs->count()): ?>
        <hr class="my-4">
        <h5>Existing Designs</h5>
        <div class="row g-3">
            <?php $__currentLoopData = $product->designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $design): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-3">
                    <div class="border rounded overflow-hidden shadow-sm">
                        <img src="<?php echo e(asset('storage/' . $design->design_image)); ?>"
                             class="img-fluid" style="height: 150px; object-fit: cover;">
                        <div class="p-2 text-center small text-muted">
                            <?php echo e($design->design_title); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views\products\edit.blade.php ENDPATH**/ ?>