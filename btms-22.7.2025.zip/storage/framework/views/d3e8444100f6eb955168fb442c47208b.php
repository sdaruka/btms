

<?php $__env->startSection('content'); ?>
    <style>
       
    </style>

    <div class="container">
        <div class="row mb-4 g-2 align-items-center">
            <div class="col-12 col-md-4">
                <h2 class="fw-bold mb-0">Manage Users</h2>
            </div>
            <?php if(Session::has('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="col-12 col-md-6">
                <form action="<?php echo e(route('users.index')); ?>" method="GET" class="d-flex">
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control me-2"
                        placeholder="Search by name or phone">
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-search"></i>
                    </button>
                </form>
            </div>
            <div class="col-12 col-md-2 text-md-end">
                <a href="<?php echo e(route('users.create')); ?>" class="btn btn-warning w-100 w-md-auto">
                    <i class="fa fa-user-plus me-1"></i> Add User
                </a>
            </div>
        </div>

        <?php if($users->count()): ?>
            <div class="table-responsive-sm">
                <table class="table table-striped table-bordered align-middle shadow-sm w-100">
                    <thead>
                        <tr class="bg-dark text-white">
                            <th>#</th>
                            <th>Profile</th>
                            <th>Name</th>
                            
                            
                            <th>Role</th>
                            <th>Status</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <img src="<?php echo e($user->profile_picture ? asset($user->profile_picture) : asset('images/default-user.png')); ?>"
                                        class="rounded-circle shadow" width="40" height="40" alt="avatar">
                                </td>
                                <td class="d-flex d-col"><?php echo e($user->name); ?> <br>
                                    <?php echo e($user->phone); ?>

                                </td>
                                
                                
                                <td>
                                    <span class="badge bg-secondary"><?php echo e(ucfirst($user->role)); ?></span>
                                </td>
                                <td>
                                    <?php if($user->is_active): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="dropdown">
                                        <button class="btn btn-light border-0" type="button" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="fa-solid fa-ellipsis-vertical"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('profile.show', ['user' => $user->id])); ?>">
                                                    <i class="fa fa-eye me-2 text-info"></i> View
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="<?php echo e(route('profile.edit', $user->id)); ?>">
                                                    <i class="fa fa-edit me-2 text-warning"></i> Edit
                                                </a>
                                            </li>
                                            <li>
                                                
                                                    <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST"
                                                        onsubmit="return confirm('Are you sure?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="dropdown-item text-danger">
                                                            <i class="fa fa-trash me-2"></i> Delete
                                                        </button>
                                                    </form>
                                                
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                <?php echo e($users->links('pagination::bootstrap-5')); ?>

            </div>
        <?php else: ?>
            <div class="alert alert-info">No users found.</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views\users\index.blade.php ENDPATH**/ ?>