

<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0">View Product</h2>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-warning">
                <i class="fa fa-backward-step me-1"></i> Back
            </a>
        </div>

        
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if(Session::has('status')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('status')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h4 class="card-title fw-bold"><?php echo e($product->name); ?></h4>
                <p class="card-text"><?php echo e($product->description ?? 'No description provided.'); ?></p>

                <hr>

                <h6 class="fw-semibold">Measurements Required:</h6>
                <?php if($product->measurements->count()): ?>
                    <div class="d-flex flex-wrap gap-2">
                        <?php $__currentLoopData = $product->measurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-secondary"><?php echo e($measurement->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted">None assigned</p>
                <?php endif; ?>

                <hr>

                <h6 class="fw-semibold">Rate History:</h6>
                <?php if($product->rates->count()): ?>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $product->rates->sortByDesc('effective_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>₹<?php echo e($rate->rate); ?></span>
                                <small class="text-muted">Effective from
                                    <?php echo e(\Carbon\Carbon::parse($rate->effective_date)->format('d M Y')); ?></small>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <p class="text-muted">No rates defined</p>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="card shadow-sm">
            <div class="card-body">
                <h6 class="fw-semibold">Default Designs:</h6>
                
                <?php if($product->designs->count()): ?>
                    <div class="row g-3">

                        <?php $__currentLoopData = $product->designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $design): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-md-3">
                                <div class="border rounded overflow-hidden shadow-sm preview-hover">
                                    <img src="<?php echo e(asset('storage/' . $design->design_image)); ?>"
                                        data-image="<?php echo e(asset('storage/' . $design->design_image)); ?>"
                                        alt="<?php echo e($design->design_title); ?>" class="img-fluid design-thumbnail"
                                        style="height: 150px; object-fit: cover; cursor: zoom-in;">

                                    <div class="p-2 text-center small text-muted">
                                        <?php echo e($design->design_title); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No designs uploaded</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
<div class="modal fade" id="designModal" tabindex="-1" aria-labelledby="designModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content bg-dark">
        <div class="modal-body p-0">
          <img src="" id="fullImage" class="w-100" style="max-height: 80vh; object-fit: contain;">
        </div>
      </div>
    </div>
  </div>
  
  
  <script>
      document.addEventListener('DOMContentLoaded', function () {
          const thumbnails = document.querySelectorAll('.design-thumbnail');
          const fullImage = document.getElementById('fullImage');
          thumbnails.forEach(thumb => {
              thumb.addEventListener('click', () => {
                  fullImage.src = thumb.dataset.image;
                  new bootstrap.Modal(document.getElementById('designModal')).show();
              });
          });
      });
    //   console.log('Modal script loaded');
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views/products/show.blade.php ENDPATH**/ ?>