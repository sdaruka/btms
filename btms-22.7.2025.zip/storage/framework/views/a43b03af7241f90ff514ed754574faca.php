

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="fw-bold mb-4">Edit Profile</h2>

        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('profile.update', ['id' => $user->id])); ?>" enctype="multipart/form-data" class="card shadow-sm p-4">
            <?php echo csrf_field(); ?>

            <div class="mb-3">

                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $user->name)); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">

                <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $user->email)); ?>"
                    placeholder="email" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">

                <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone', $user->phone)); ?>">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php
    $enumRoles = DB::select("SHOW COLUMNS FROM users WHERE Field = 'role'");
    preg_match('/enum\((.*)\)/', $enumRoles[0]->Type, $matches);
    $roles = collect(explode(',', str_replace(["'", '"'], '', $matches[1])));
?>

<div class="mb-3">
    <select name="role" class="form-select" id="role">
        <option value="" disabled>Select role</option>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($roleOption); ?>" <?php echo e(old('role', $user->role) === $roleOption ? 'selected' : ''); ?>>
                <?php echo e(ucfirst($roleOption)); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-3">
    <input type="radio" name="is_active" value="1" <?php echo e($user->is_active ? 'checked' : ''); ?>>
    <label for="is_active">Active</label>
    <input type="radio" name="is_active" value="0" <?php echo e(!$user->is_active ? 'checked' : ''); ?>>
    <label for="is_inactive">Inactive</label>
</div>
        
            <div class="mb-3">

                <input type="text" name="address" class="form-control" value="<?php echo e(old('address', $user->address)); ?>">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">

                <input type="text" name="country" class="form-control" value="<?php echo e(old('country', $user->country)); ?>">
                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <span class="text-warning">Max upload size: 2MB</span>
                <input type="file" name="profile_picture" class="form-control">
                <?php $__errorArgs = ['profile_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php if($user->profile_picture): ?>
                    <div class="mt-2">
                        <img src="<?php echo e(asset($user->profile_picture)); ?>" class="rounded" width="80" height="80"
                            alt="Current photo">
                    </div>
                <?php endif; ?>
            </div>
            <hr>
            <h5 class="mb-3">Change Password (optional)</h5>

            <div class="mb-3">

                <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">

                <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm new password">
            </div>


            <button type="submit" class="btn btn-danger">Update Profile</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views\profile\edit.blade.php ENDPATH**/ ?>