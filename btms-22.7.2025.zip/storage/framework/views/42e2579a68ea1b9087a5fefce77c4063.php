
<?php $__env->startSection('title','Orders'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Orders</h2>
    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-warning">
        <i class="fa-solid fa-boxes-stacked me-2"></i>New Order</a>
  </div>

  <?php if($orders->count()): ?>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>Order No.</th>
          <th>Customer</th>
          <th>Order Date</th>
          <th>Delivery</th>
          <th>Total</th>
          <th>Status</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration + ($orders->currentPage()-1)*$orders->perPage()); ?></td>
            <td><?php echo e($order->order_number); ?></td>
            <td><?php echo e($order->user->name); ?></td>
            <td><?php echo e($order->order_date->format('d M Y')); ?></td>
            <td><?php echo e(optional($order->delivery_date)->format('d M Y')); ?></td>
            <td>₹<?php echo e($order->total_amount); ?></td>
            <td><?php echo e($order->status); ?></td>
            <td>
              <a href="<?php echo e(route('orders.show',$order)); ?>" class="btn btn-sm btn-info">View</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php echo e($orders->links('pagination::bootstrap-5')); ?>

  <?php else: ?>
    <div class="alert alert-info">No orders found.</div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views\orders\index.blade.php ENDPATH**/ ?>