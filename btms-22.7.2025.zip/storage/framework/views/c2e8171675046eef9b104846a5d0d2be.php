
<?php $__env->startSection('title', 'New Order'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-4">Place New Order</h2>

        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('orders.store')); ?>" method="POST" enctype="multipart/form-data" x-data="orderForm()">
            <?php echo csrf_field(); ?>

            
            <div class="row mb-4 bg-dark text-white p-2 rounded">
                <div class="col-md-3 mb-3">
                    <label class="form-label">Customer</label>
                    <select name="user_id" class="form-select <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Select customer</option>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cust): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cust->id); ?>" <?php echo e(old('user_id') == $cust->id ? 'selected' : ''); ?>>
                                <?php echo e($cust->name); ?> (<?php echo e($cust->phone); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Delivery Date</label>
                    <input type="date" name="delivery_date"
                        class="form-control <?php $__errorArgs = ['delivery_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('delivery_date', now()->addDays(10)->format('Y-m-d'))); ?>">
                    <?php $__errorArgs = ['delivery_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Order Date</label>
                    <input type="date" name="order_date"
                        class="form-control <?php $__errorArgs = ['Order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('order_date', now()->format('Y-m-d'))); ?>" readonly>
                    <?php $__errorArgs = ['order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-3 mb-3">
                    <label class="form-label">Order Number</label>
                    <input type="number" name="order_number"
                        class="form-control <?php $__errorArgs = ['Order_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e($invoiceNumber); ?>" readonly>
                    <?php $__errorArgs = ['order_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            
            <div class="mb-4 d-flex ">
                <select x-model="selectedProduct" class="form-select me-2">
                    <option value="">-- Select an item to add --</option>
                    <template x-for="prod in products" :key="prod.id">
                        <option :value="prod.id" x-text="prod.name"></option>
                    </template>
                </select>
                <button type="button" class="btn btn-warning w-50 fw-semibold" :disabled="!selectedProduct"
                    @click="addItem()">
                    <i class="fa fa-circle-plus"></i>
                    Add Item
                </button>
            </div>

            
            <div id="itemsContainer">
                <template x-for="(item, idx) in items" :key="item.id">
                    <div class="card mb-3" :data-product-id="item.id">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span x-text="item.name"></span>
                            <button type="button" class="btn-close" @click="removeItem(idx)"></button>
                        </div>
                        <div class="card-body">
                            <input type="hidden" :name="`items[${idx}][product_id]`" :value="item.id">
                            
                            <div class="mb-3">
                                <label class="form-label">Measurements</label>

                                <div class="row">
                                    <template x-for="(meas, mi) in item.measurements" :key="meas.id">
                                        <div class="col-12 col-sm-6 col-md-3 mb-2">
                                            <div class="input-group">
                                                <span class="input-group-text" x-text="meas.name"></span>
                                                <input type="hidden" :name="`items[${idx}][measurements][${meas.id}][id]`"
                                                    :value="meas.id">
                                                <input type="text"
                                                    :name="`items[${idx}][measurements][${meas.id}][value]`"
                                                    class="form-control" :placeholder="`Enter ${meas.name}`">
                                            </div>
                                        </div>
                                    </template>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Select Designs</label>

                                <div class="d-flex flex-nowrap overflow-auto gap-2">
                                    <template x-for="design in item.designs" :key="design.id">
                                        <label class="position-relative border rounded p-2"
                                            :class="{
                                                'border-primary border-2': item.selectedDesignIds.includes(design.id)
                                            }"
                                            style="cursor: pointer; min-width: 120px;">
                                            <input type="checkbox"
                                                class="form-check-input position-absolute top-0 end-0 m-2"
                                                :value="design.id" :name="`items[${idx}][design_ids][]`"
                                                x-model="item.selectedDesignIds">

                                            <img :src="design.image_url" class="img-fluid mb-1"
                                                style="height: 80px; object-fit: cover;" :alt="design.design_title">

                                            <div class="text-center small" x-text="design.design_title"></div>
                                        </label>
                                    </template>
                                </div>
                            </div>

                            
                            <div class="mb-3">
                                <label class="form-label">Upload Custom Design</label>
                                <input type="file" :name="`items[${idx}][design_images][]`" class="form-control"
                                    multiple accept="image/*">
                                <small class="text-muted">Optional – overrides chosen design</small>
                            </div>

                            
                            <div class="mb-3">
                                <label class="form-label">Custom Design Title</label>
                                <input type="text" :name="`items[${idx}][custom_design_title]`" class="form-control"
                                    placeholder="e.g. My Sketch">
                            </div>




                            
                            <div class="row">
                                <div class="col-12 col-sm-6 col-md-4 mb-2">
                                    <label class="form-label">Rate</label>
                                    <input type="number" :name="`items[${idx}][rate]`" class="form-control"
                                        :value="item.current_rate" readonly>

                                </div>
                                <div class="col-12 col-sm-6 col-md-4 mb-2">
                                    <label class="form-label">Quantity</label>
                                    <input type="number" :name="`items[${idx}][quantity]`" class="form-control"
                                        x-model="item.quantity" min="1" step="1" placeholder="e.g. 5">
                                </div>


                            </div>

                        </div>
                </template>
                
                <div class="card shadow-sm mb-3  bg-dark text-white">
                    <div class="card-header">
                        <h5 class="mb-0">Invoice Summary</h5>
                    </div>
                    <div class="card-body">

                        <p class="card-text">Review your order details before placing the order.</p>

                        <div class="d-flex gap-3 align-items-center text-warning mb-2">
                            <h6><i class="fa-solid fa-file-invoice-dollar"></i> Sub Total:</h5>
                            <h6 class="text-warning" x-text="'₹' + subtotal.toFixed(2)"></h5>
                        </div>

                        <div class="d-flex gap-3 align-items-center text-warning mb-2">
                            <h6><i class="fa-solid fa-circle-minus"></i> Discount:</h5>
                            <input type="number" name="discount" x-model="discount"
                                class="form-control w-25 text-warning" min="0"
                                placeholder="Enter discount amount">
                        </div>

                        <div class="d-flex gap-3 align-items-center text-warning mb-3">
                            <h6><i class="fa-solid fa-file-invoice-dollar"></i> Total Amount:</h5>
                            <h6 class="text-warning" x-text="'₹' + total.toFixed(2)"></h5>
                        </div>
                    </div>

                    
                    <input type="hidden" name="total_amount" x-model="total">
                    <input type="hidden" name="discount" x-model="discount">
                </div>
                <button type="submit" class="btn btn-danger w-100">
                    <i class="fa fa-save"></i>
                    Place Order</button>
        </form>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    
    <script>
        function orderForm() {

            return {
                // All products as JSON
                products: <?php echo json_encode($productsJson, 15, 512) ?>,

                selectedProduct: '',
                items: [],
                discount: <?php echo e(old('discount', 0)); ?>,
                addItem() {
                    // Prevent dupes
                    if (this.items.find(i => i.id == this.selectedProduct)) {
                        this.selectedProduct = '';
                        return;
                    }
                    const prod = this.products.find(p => p.id == this.selectedProduct);
                    let newItem = JSON.parse(JSON.stringify(prod));

                    newItem.selectedDesignIds = []; // for multi-select
                    newItem.quantity = 1;
                    this.items.push(newItem);
                    this.selectedProduct = '';
                },
                get subtotal() {
                    return this.items.reduce((sum, item) => {
                        const qty = parseInt(item.quantity) || 1;
                        const rate = parseFloat(item.current_rate || 0);
                        return sum + qty * rate;
                    }, 0);
                },

                get total() {
                    return Math.max(0, this.subtotal - parseFloat(this.discount || 0));
                },
                removeItem(idx) {
                    this.items.splice(idx, 1);
                }
            }

        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views\orders\create.blade.php ENDPATH**/ ?>