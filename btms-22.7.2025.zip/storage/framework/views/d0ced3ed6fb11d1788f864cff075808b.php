

<script>
    window.initialCustomers = Array.from(
        new Map(<?php echo json_encode($customers, 15, 512) ?>.map(c => [c.id, c])).values()
    );
</script>
<script>
    function orderForm() {
        return {
            selectedUserId: '<?php echo e(old('user_id') ?? ''); ?>',
            selectedProduct: '',
            products: <?php echo json_encode($productsJson, 15, 512) ?>,
            // customers: <?php echo json_encode($customers, 15, 512) ?>,
            customers: window.initialCustomers,
            discount: <?php echo e(old('discount', 0)); ?>,
            received: <?php echo e(old('received', 0)); ?>,
            showModal: false,
            newCustomer: {
                name: '',
                phone: ''
            },
            previousMeasurements: {},
            items: [],

            init() {
                this.items = <?php echo json_encode(old('items') ?? [], 15, 512) ?>.map(item => ({
                    id: item.product_id,
                    name: this.products.find(p => p.id == item.product_id)?.name || '',
                    rate: item.rate,
                    quantity: item.quantity || 1,
                    measurements: item.measurements || [],
                    designs: this.products.find(p => p.id == item.product_id)?.designs || [],
                    selectedDesignIds: item.design_ids || [],
                    custom_design_title: item.custom_design_title || ''
                }));
            },

            addItem() {
                if (!this.selectedUserId) {
                    alert("Select a customer first.");
                    return;
                }

                const existing = this.items.find(i => i.id == this.selectedProduct);
                if (existing) {
                    alert("Item already added.");
                    this.selectedProduct = '';
                    return;
                }

                const prod = this.products.find(p => p.id == this.selectedProduct);
                if (!prod) return;

                const prev = this.previousMeasurements[this.selectedProduct]?.[0];

                const measurements = prev?.measurements?.map(m => ({
                    id: m.id,
                    name: m.name,
                    pivot: {
                        value: m.pivot?.value ?? 0
                    },
                })) || prod.measurements.map(m => ({
                    id: m.id,
                    name: m.name,
                    pivot: {
                        value: 0
                    }
                }));

                this.items.push({
                    id: prod.id,
                    name: prod.name,
                    rate: prod.current_rate,
                    quantity: 1,
                    measurements: measurements,
                    designs: prod.designs,
                    selectedDesignIds: [],
                    custom_design_title: '',
                });

                this.selectedProduct = '';
            },

            removeItem(index) {
                this.items.splice(index, 1);
            },

            fetchPreviousMeasurements() {
                fetch(`/orders/measurements/${this.selectedUserId}`)
                    .then(res => res.json())
                    .then(data => this.previousMeasurements = data)
                    .catch(() => console.error("Measurement fetch failed"));
            },
            customerErrors: {},
            customerErrorMessage: '',

createCustomer() {
    const fd = new FormData();
    fd.append('name', this.newCustomer.name);
    fd.append('phone', this.newCustomer.phone);

    fetch('<?php echo e(url('customer')); ?>', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        },
        body: fd,
    })
    .then(async res => {
        const data = await res.json();

        if (!res.ok || !data.id) {
            this.customerErrorMessage = data.message || 'Could not create customer.';
            this.customerErrors = data.errors || {};
            return;
        }

        // ✅ Replace if exists, else push
        const index = this.customers.findIndex(c => String(c.id) === String(data.id));
        if (index >= 0) {
            this.customers.splice(index, 1, data); // replaces existing user
        } else {
            this.customers.push(data);
        }

        this.selectedUserId = String(data.id);
        this.newCustomer = { name: '', phone: '' };
        this.customerErrors = {};
        this.customerErrorMessage = '';
        this.showModal = false;
    })
    .catch(() => {
        this.customerErrorMessage = 'Network error. Please try again.';
    });
},

            get subtotal() {
                return this.items.reduce((sum, item) => {
                    const qty = parseInt(item.quantity) || 1;
                    const rate = parseFloat(item.rate) || 0;
                    return sum + (qty * rate);
                }, 0);
            },

            get total() {
                return Math.max(0, this.subtotal - parseFloat(this.discount || 0));
            },
        }
    }
</script>
<?php /**PATH D:\btms\resources\views/orders/alpine.blade.php ENDPATH**/ ?>