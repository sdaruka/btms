<!-- resources/views/dashboard/index.blade.php -->
<?php /**PATH D:\btms\resources\views\dashboard\index.blade.php ENDPATH**/ ?>