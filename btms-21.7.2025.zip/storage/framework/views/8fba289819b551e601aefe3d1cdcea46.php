<nav class="sidebar p-3 d-flex flex-column justify-content-between" id="sidebar">
    <div>
        <div class="text-center mb-2">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="BTMS Logo" class="img-fluid" style="max-width: 7vh;">
        </div>

        <?php
            $user = Auth::user();
            $imagePath =
                !empty($user->profile_picture) && file_exists(public_path($user->profile_picture))
                    ? asset($user->profile_picture)
                    : asset('images/default-user.svg');
        ?>

        <div class="d-flex align-items-center mb-3 profile-section">
            <a href="<?php echo e(route('profile.show', ['user' => $user->id])); ?>"
                class="d-flex align-items-center text-warning gap-3 text-decoration-none" data-bs-toggle="tooltip"
                data-bs-placement="top" title="Update profile">

                <img src="<?php echo e($imagePath); ?>" class="rounded-circle shadow-lg" width="50" height="50"
                    alt="Profile Picture" style="border: 1px solid #d5d6d3;">

                <div class="d-flex flex-column">
                    <span class="text-white fw-semibold"><?php echo e($user->name); ?></span>
                </div>

                <i class="fa-solid fa-square-pen fs-5 ms-2"></i>
            </a>
        </div>

        <?php
            $current = Request::segment(1);
        ?>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a href="<?php echo e(url('/dashboard')); ?>"
                    class="nav-link <?php echo e($current === 'dashboard' ? 'active fw-bold text-warning' : 'text-white'); ?>">
                    <i class="fa-solid fa-gauge me-2"></i> Dashboard
                </a>
            </li>
            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'staff'): ?>
                <li class="nav-item">
                    <a href="<?php echo e(url('/products')); ?>"
                        class="nav-link  <?php echo e($current === 'products' ? 'active fw-bold text-warning' : 'text-white'); ?>">
                        <i class="fa-solid fa-shirt me-2"></i> Products
                    </a>
                </li>
            <?php endif; ?>
            <li class="nav-item">
                <a href="<?php echo e(url('/orders')); ?>"
                    class="nav-link <?php echo e($current === 'orders' ? 'active fw-bold text-warning' : 'text-white'); ?>">
                    <i class="fa-solid fa-boxes-stacked me-2"></i> Orders
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(url('#')); ?>"
                    class="nav-link text-white <?php echo e($current === 'jobs' ? 'active fw-bold' : ''); ?>">
                    <i class="fa-solid fa-briefcase me-2"></i> Jobs
                </a>
            </li>
            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'staff'): ?>
                <li class="nav-item">
                    <a href="<?php echo e(url('/users')); ?>"
                        class="nav-link <?php echo e($current === 'users' ? 'active fw-bold text-warning' : 'text-white'); ?>">
                        <i class="fa-solid fa-user-group me-2"></i> Users
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </div>

    <!-- Bottom Section -->
    <div>
        <form method="GET" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-warning w-100">Logout</button>
        </form>
    </div>

</nav>
<?php /**PATH D:\btms\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>