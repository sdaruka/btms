
<?php $__env->startSection('title', 'Edit Order'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container" x-data="editOrderForm()">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0">Edit Orders</h2>
            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-warning">
                <i class="fa fa-backward-step me-1"></i> Back
            </a>
        </div>

        <form action="<?php echo e(route('orders.update', $order)); ?>" method="POST" enctype="multipart/form-data"
            x-init="init()" x-data="orderForm(true)">
            <?php echo csrf_field(); ?>
            

            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <div class="row mb-3 bg-dark text-white p-2 rounded">
                <div class="col-md-3">
                    <select name="user_id" class="form-select">
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e($order->user_id == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->name); ?> | <?php echo e($user->phone); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-text bg-dark text-white">Order Date</span>
                        <input type="date" name="order_date" readonly
                            value="<?php echo e(old('order_date', \Carbon\Carbon::parse($order->order_date)->format('Y-m-d'))); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-text bg-dark text-white">Delivery Date</span>
                        <input type="date" name="delivery_date"
                            value="<?php echo e(old('delivery_date', \Carbon\Carbon::parse($order->delivery_date)->format('Y-m-d'))); ?>"
                            class="form-control">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-text bg-dark text-white">Order No.</span>
                        <input type="text" name="order_number" value="<?php echo e(old('order_number', $order->order_number)); ?>"
                            class="form-control" readonly>
                    </div>
                </div>
            </div>

            
            <?php echo $__env->make('orders.partial.items', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <?php echo $__env->make('orders.partial.invoice', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <button type="submit" class="btn btn-danger mt-3 w-100">Update Order</button>
        </form>
    </div>


    
    <?php echo $__env->make('orders.partial.alpine', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views/orders/edit.blade.php ENDPATH**/ ?>