
<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-4 g-2 align-items-center">

            <div class="col-12 col-md-4">
                <h2 class="fw-bold mb-0">Orders</h2>
            </div>

            <div class="col-12 col-md-4">
                <form action="<?php echo e(route('orders.index')); ?>" method="GET" class="d-flex">
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control me-2"
                        placeholder="Search by customer name or order numer">
                    <input type="date" name="search_date" class="form-control" />

                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-search"></i>
                    </button>
                </form>
            </div>
            <div class="col-12 col-md-4 text-md-end">
                <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'staff'): ?>
                    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-warning">
                        <i class="fa-solid fa-boxes-stacked me-2"></i>New Order</a>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <?php if($orders->count()): ?>
        <div class="table-responsive">
            <table class="table table-striped table-sm ">
                <thead>
                    <tr>
                        <th>#</th>
                        
                        <th>Customer Name | Number </th>
                        
                        <th>Delivery</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isOverdue =
                                \Carbon\Carbon::parse($order->delivery_date)->isPast() &&
                                $order->status !== 'Completed';
                        ?>

                        <tr <?php if($isOverdue): ?> class="table-warning" <?php endif; ?>>
                            <td><?php echo e($loop->iteration + ($orders->currentPage() - 1) * $orders->perPage()); ?></td>
                            
                            <td><?php echo e($order->user->name); ?> | <?php echo e($order->user->phone); ?></td>
                            
                            <td><?php echo e(\Carbon\Carbon::parse($order->delivery_date)->format('d M Y')); ?></td>
                            <td>₹<?php echo e($order->total_amount); ?></td>
                            <td style="position: relative;">
                                <div class="dropdown" x-data="{ status: '<?php echo e($order->status); ?>' }">
                                    <button type="button" class="badge dropdown-toggle" data-bs-toggle="dropdown"
                                        aria-expanded="false" style="cursor: pointer; border: none;"
                                        :class="{
                                            'bg-primary': status === 'Assigned',
                                            'bg-info': status === 'Completed',
                                            'bg-warning': status === 'Pending',
                                            'bg-danger': status === 'Cancelled',
                                            'bg-dark': status === 'Alteration',
                                            'bg-success': status === 'Delivered',
                                            'bg-light text-info': status === 'In Progress',
                                            'bg-secondary': ![
                                                'Assigned', 'Pending', 'Completed', 'Cancelled',
                                                'Alteration', 'Delivered', 'In Progress'
                                            ].includes(status)
                                        }"
                                        x-text="status">
                                    </button>

                                    <ul class="dropdown-menu dropdown-menu-end shadow"
                                        style="max-height: 250px; overflow-y: visible;">
                                        <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'staff'): ?>
                                            <?php $__currentLoopData = ['Assigned', 'Pending', 'Completed', 'Cancelled', 'Alteration', 'Delivered', 'In Progress']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <button type="button" class="dropdown-item"
                                                        @click="
                                                            fetch('<?php echo e(route('orders.updateStatus', $order)); ?>', {
                                                                method: 'PATCH',
                                                                headers: {
                                                                    'Content-Type': 'application/json',
                                                                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                                                                },
                                                                body: JSON.stringify({ status: '<?php echo e($s); ?>' })
                                                            }).then(res => res.ok && (status = '<?php echo e($s); ?>'))
                                                        ">
                                                        <?php echo e($s); ?>

                                                    </button>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php $__currentLoopData = ['Assigned', 'Completed', 'In Progress']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <button type="button" class="dropdown-item"
                                                        @click="
                                                            fetch('<?php echo e(route('orders.updateStatus', $order)); ?>', {
                                                                method: 'PATCH',
                                                                headers: {
                                                                    'Content-Type': 'application/json',
                                                                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                                                                },
                                                                body: JSON.stringify({ status: '<?php echo e($s); ?>' })
                                                            }).then(res => res.ok && (status = '<?php echo e($s); ?>'))
                                                        ">
                                                        <?php echo e($s); ?>

                                                    </button>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </ul>
                                </div>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-sm " type="button" data-bs-toggle="dropdown" >
                                        <i class="fa fa-ellipsis-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item text-primary" style="cursor: pointer"
                                                href="<?php echo e(route('orders.print', $order)); ?>">
                                                <i class="fa fa-print me-2 text-primary"></i>Print</a>
                                        </li>
                                        <li><a class="dropdown-item text-info" href="<?php echo e(route('orders.show', $order)); ?>">
                                                <i class="fa fa-eye me-2 text-info"></i>View</a>
                                        </li>
                                        <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'staff'): ?>
                                            <li><a class="dropdown-item text-warning"
                                                    href="<?php echo e(route('orders.edit', $order)); ?>">
                                                    <i class="fa fa-edit me-2 text-warning"></i>Edit</a>
                                            </li>

                                            <li>
                                                <form action="<?php echo e(route('orders.destroy', $order)); ?>" method="POST"
                                                    onsubmit="return confirm('Delete this order?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item text-danger">
                                                        <i class="fa fa-trash me-2 text-danger"></i> Delete</button>
                                                </form>
                                            </li>
                                        <?php endif; ?>
                                        <li><a class="dropdown-item text-success" style="cursor: pointer"
                                                data-bs-toggle="modal" data-bs-target="#assignModal<?php echo e($order->id); ?>">
                                                <i class="fa-solid fa-people-arrows me-2 text-success"></i> Assign To</a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($orders->links('pagination::bootstrap-5')); ?>

    <?php else: ?>
        <div class="alert alert-info">No orders found.</div>
    <?php endif; ?>
    </div>
    
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Dropdown trigger -->
        <?php echo $__env->make('orders.assign', ['order' => $order, 'tailors' => $tailors], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views/orders/index.blade.php ENDPATH**/ ?>