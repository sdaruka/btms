<script>
    function orderForm(isEdit = false, rawData = {}) {

        const products = @json($productsJson);

        const oldItems = @json(old('items') ?? ($order->items ?? []));
        const customers = window.initialCustomers = Array.from(
            new Map(@json($customers).map(c => [c.id, c])).values()
        );

        return {
            isEdit,
            selectedUserId: @json(old('user_id') ?? ($order->user_id ?? '')),
            selectedCustomerId: @json(old('customer_id') ?? ($order->customer_id ?? '')),
            // measurements: @json($measurements),
            measurements: @json($measurements->map(fn($m) => ['id' => $m->id, 'name' => $m->name])),
            selectedProduct: '',
            products,
            customers,
            discount: {{ old('discount', $order->discount ?? 0) }},
            design_charge: {{ old('design_charge', $order->design_charge ?? 0) }},
            received: {{ old('received', $order->received ?? 0) }},
            showModal: false,
            newCustomer: {
                name: '',
                phone: ''
            },
            previousMeasurements: {},
            items: [],
            hoveredPreview: null,
            customerErrors: {},
            customerErrorMessage: '',

            productErrorMessage: '',
            showItemModal: false,

            newProduct: {
                name: '',
                description: '',
                rate: '',
                effective_date: '',
                measurement_ids: [],
                images: [],
            },


            init() {
                this.items = oldItems.map(item => {
                    const prod = products.find(p => p.id == (item.product_id ?? item.id));
                    const designs = (prod?.designs || []).map(d => ({
                        id: d.id,
                        design_title: d.design_title,
                        image_url: d.image_url ?? '/placeholder.jpg'
                    }));

                    return {
                        id: prod?.id ?? item.product_id,
                        name: prod?.name ?? '',
                        rate: item.rate ?? prod?.current_rate ?? 0,
                        quantity: item.quantity || 1,
                        designs: designs,
                        selectedDesignIds: item.design_ids || item.designs?.map(d => d.id) || [],
                        custom_design_title: item.custom_design_title || '',
                        measurements: (prod?.measurements || []).map(m => {
                            const matched = (item.measurements || []).find(im => im.id === m.id);
                            return {
                                id: m.id,
                                name: m.name,
                                pivot: {
                                    value: matched?.pivot?.value || matched?.value || 0
                                }
                            };
                        })
                    };
                });
            },

            addItem() {
                if (!this.selectedUserId) {
                    alert("Select a customer first.");
                    return;
                }

                const existing = this.items.find(i => i.id == this.selectedProduct);
                if (existing) {
                    alert("Item already added.");
                    this.selectedProduct = '';
                    return;
                }

                const prod = this.products.find(p => p.id == this.selectedProduct);
                if (!prod) return;

                const prev = this.previousMeasurements[this.selectedProduct]?.[0];

                // const measurements = this.measurements.map(global => {
                //     const source = (prev?.measurements ?? prod.measurements).find(m => m.id === global.id);
                //     return {
                //         id: global.id,
                //         name: global.name,
                //         pivot: {
                //             value: source?.pivot?.value ?? 0
                //         }
                //     };
                // });
                const allowedIds = prod.measurements.map(m => m.id);

                const measurements = this.measurements
                    .filter(m => allowedIds.includes(m.id))
                    .map(m => {
                        const source = (prev?.measurements ?? prod.measurements).find(pm => pm.id === m.id);
                        return {
                            id: m.id,
                            name: m.name,
                            pivot: {
                                value: source?.pivot?.value ?? 0
                            }
                        };
                    });



                const designs = (prod?.designs || []).map(d => ({
                    id: d.id,
                    design_title: d.design_title,
                    image_url: d.image_url ?? '/placeholder.jpg'
                }));

                this.items.push({
                    id: prod.id,
                    name: prod.name,
                    rate: prod.current_rate ?? 0,
                    quantity: 1,
                    measurements,
                    designs,
                    selectedDesignIds: [],
                    custom_design_title: '',
                });

                this.selectedProduct = '';
            },

            removeItem(index) {
                this.items.splice(index, 1);
            },

            replaceProduct(i, productId) {
                const prod = this.products.find(p => p.id == productId);
                this.items[i].id = productId;
                this.items[i].rate = prod?.current_rate ?? 0;
                this.items[i].designs = (prod?.designs || []).map(d => ({
                    id: d.id,
                    design_title: d.design_title,
                    image_url: d.image_url ?? '/placeholder.jpg'
                }));
                this.items[i].measurements = (prod?.measurements || []).map(m => ({
                    id: m.id,
                    name: m.name,
                    pivot: {
                        value: ''
                    }
                }));
                this.items[i].selectedDesignIds = [];
            },

            fetchPreviousMeasurements() {
                fetch(`/orders/measurements/${this.selectedUserId}`)
                    .then(res => res.json())
                    .then(data => this.previousMeasurements = data)
                    .catch(() => console.error("Measurement fetch failed"));
            },

            createCustomer() {
                const fd = new FormData();
                fd.append('name', this.newCustomer.name);
                fd.append('phone', this.newCustomer.phone);

                fetch('{{ url('customer') }}', {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: fd,
                    })
                    .then(async res => {
                        const data = await res.json();

                        if (!res.ok || !data.id) {
                            this.customerErrorMessage = data.message || 'Could not create customer.';
                            this.customerErrors = data.errors || {};
                            return;
                        }

                        const index = this.customers.findIndex(c => String(c.id) === String(data.id));
                        if (index >= 0) {
                            this.customers.splice(index, 1, data);
                        } else {
                            this.customers.push(data);
                        }

                        this.selectedUserId = String(data.id);
                        this.newCustomer = {
                            name: '',
                            phone: ''
                        };
                        this.customerErrors = {};
                        this.customerErrorMessage = '';
                        this.showModal = false;
                    })
                    .catch(() => {
                        this.customerErrorMessage = 'Network error. Please try again.';
                    });
            },
            createProduct() {
                this.productErrorMessage = '';

                const fd = new FormData();
                fd.append('name', this.newProduct.name);
                fd.append('description', this.newProduct.description);
                fd.append('rate', this.newProduct.rate);
                fd.append('effective_date', this.newProduct.effective_date);
                this.newProduct.measurement_ids.forEach(id => fd.append('measurement_ids[]', id));
                Array.from(this.newProduct.images).forEach(img => fd.append('images[]', img));

                fetch('{{ route('products.store') }}', {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute(
                                'content'),
                            'Accept': 'application/json'
                        },
                        body: fd,
                    })
                    .then(async res => {
                        const data = await res.json();
                        if (!res.ok || !data.id) {
                            this.productErrorMessage = data.message || 'Product creation failed.';
                            return;
                        }

                        // Append to product list
                        this.products.push({
                            id: data.id,
                            name: data.name,
                            current_rate: data.rate,
                            designs: data.designs ?? [],
                            measurements: data.measurements ?? [],
                        });

                        this.selectedProduct = String(data.id);
                        this.showItemModal = false;
                        this.newProduct = {
                            name: '',
                            description: '',
                            rate: '',
                            effective_date: '',
                            measurement_ids: [],
                            images: []
                        };
                    })
                    .catch((err) => {
                        console.error("Product creation failed", err);
                        this.productErrorMessage = 'Network error. Check console for details.';
                    });
            },
            get subtotal() {
                return this.items.reduce((sum, item) => {
                    const qty = parseInt(item.quantity) || 1;
                    const rate = parseFloat(item.rate) || 0;
                    return sum + (qty * rate);
                }, 0);
            },

            get total() {
                return Math.max(0, this.subtotal - parseFloat(this.discount || 0) + parseFloat(this.design_charge ||
                    0) - parseFloat(this.received || 0));
            },

            submitForm() {
                this.$root.submit();
            }
        };
    }
</script>
