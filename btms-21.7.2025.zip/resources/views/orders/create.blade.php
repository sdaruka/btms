@extends('layouts.main')
@section('title', 'New Order')
@section('content')
    <div class="container">
        <h2 class="mb-4">Place New Order</h2>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $msg)
                        <li>{{ $msg }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        @if (session('status'))
            <div class="alert alert-info">{{ session('status') }}</div>
        @endif

        <form action="{{ route('orders.store') }}" method="POST" enctype="multipart/form-data" x-data="orderForm(false)"
            x-init="init()" @submit.prevent="submitForm()" @submit.prevent="createCustomer()">
            @csrf

            @include('orders.partial.customer')

            {{-- Add Item --}}
            @include('orders.partial.items')
            @include('products.product-modal')

            @include('orders.partial.invoice')

    </div>
    <button type="submit" class="btn btn-danger w-100">
        <i class="fa fa-save"></i>
        Place Order</button>
    {{-- <div x-effect="console.log('Selected user changed to:', selectedUserId)"> --}}

    </form>
    
    <img x-show="hoveredPreview" :src="hoveredPreview" class="thumb-preview"
        @mousemove="(e) => {
         $el.style.left = (e.pageX + 20) + 'px';
         $el.style.top = (e.pageY + 20) + 'px';
     }"
        @mouseleave="hoveredPreview = null">
    @include('orders.partial.alpine')

@endsection
