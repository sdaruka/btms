@section('title', 'Add Product')

<div x-show="showItemModal" class="modal-backdrop"
     @keydown.escape.window="showItemModal = false"
     style="position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.6); z-index:1050;">

    <meta name="csrf-token" content="{{ csrf_token() }}">

    <div class="modal-content bg-white rounded-4 shadow-lg p-4 position-relative"
         style="max-width: 60vw; max-height: 80vh; margin: 2% auto; animation: fadeInUp 0.3s ease-out;overflow:auto;">

        <h5 class="mb-3 fw-semibold border-bottom pb-2">
            <i class="fa fa-box text-primary me-2"></i> Add Product
        </h5>

        <!-- Error Message -->
        <template x-if="productErrorMessage">
            <div class="alert alert-danger py-2 px-3 small mb-3" x-text="productErrorMessage"></div>
        </template>

        <!-- Product Name -->
        <div class="row d-flex justify-content-between mb-2">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-dark text-warning">Product Name</span>
               
            
            <input type="text" x-model="newProduct.name" id="product-name" class="form-control" placeholder="e.g. Summer Kurti">    
         </div>    
        </div>
            <div class="col-md-6">
            <div class="input-group">
            <input type="text" x-model="newProduct.description" id="product-description" class="form-control" rows="2" placeholder="Short description...">
                    <span class="input-group-text bg-dark text-warning">Description</span>
        </div>
        </div>
        </div>
        
        <!-- Description -->
        

        <!-- Measurements -->
        <div class="mb-2">
            <label class="form-label d-block">Measurements</label>
            <div class="row">
                <template x-for="(m, index) in measurements" :key="m.id">
                    <div class="col-3 mb-1">
                        <div class="form-check">
                            <input type="checkbox" :id="`m-${m.id}`" :value="m.id" x-model="newProduct.measurement_ids" class="form-check-input">
                            <label class="form-check-label small" :for="`m-${m.id}`" x-text="m.name"></label>
                        </div>
                    </div>
                </template>
            </div>
        </div>

        <!-- Rate & Date -->
        <div class="row g-2 mb-2">
            <div class="col-6">
                <div class="input-group">
                    <span class="input-group-text bg-dark text-warning">Rate (₹)</span>
                <input type="number" x-model="newProduct.rate" id="product-rate" class="form-control" placeholder="e.g. 500">
                
                </div>
                
            </div>
            <div class="col-6">
                <div class="input-group">
                    <span class="input-group-text bg-dark text-warning">Date</span>
                <input type="date" x-model="newProduct.effective_date" id="effective-date" class="form-control">
                </div>
            </div>
        </div>

        <!-- Images -->
        <div class="mb-2">
            <label class="form-label" for="product-images">Upload Images</label>
            <input type="file" id="product-images" @change="newProduct.images = $event.target.files" multiple accept="image/*" class="form-control">
            <small class="text-muted">You can select multiple files</small>
        </div>

        <!-- Actions -->
        <div class="d-flex justify-content-end gap-2 mt-3">
            <button type="button" class="btn btn-outline-secondary" @click="showItemModal = false">
                <i class="fa fa-times me-1"></i> Cancel
            </button>
            <button type="button" class="btn btn-success" @click="createProduct()">
                <i class="fa fa-check me-1"></i> Save
            </button>
        </div>
    </div>
</div>

<style>
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>
