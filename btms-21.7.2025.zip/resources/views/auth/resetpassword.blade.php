<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bhumis: Reset Password</title>
    <link rel="icon" href="{{ asset('images/logo.png') }}" type="image">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body class="d-flex align-items-center justify-content-center max-vh-100 mt-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">
                <div class="card shadow-lg">
                    <!-- Card Header -->
                    <div class="card-header text-center">
                        <div class="d-flex align-items-center justify-content-center mb-3">
                            <img src="{{ asset('images/logo.png') }}" alt="Bhumis Logo" class="img-fluid" style="max-width: 5vw;">
                        </div>
                        <h3 class="fw-bold text-dark">Reset Password</h3>
                    </div>

                    <!-- Card Body -->
                    <div class="card-body p-4">
                        @if (Session::has('error'))
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                {{ Session::get('error') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                            @elseif (Session::has('status'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ Session::get('status') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>    
                        @endif

                        <!-- Tab Navigation -->
                        <ul class="nav nav-tabs justify-content-around mb-2" id="loginTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="tab-button {{ session('active_tab', 'phone') === 'phone' ? 'active' : '' }}" id="tab-phone-login-button" data-bs-toggle="tab"
                                    data-bs-target="#tab-phone-login" type="button" role="tab"
                                    aria-controls="tab-phone-login" aria-selected="true">
                                    Reset with Phone
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="tab-button {{ session('active_tab') === 'email' ? 'active' : '' }}" id="tab-email-login-button" data-bs-toggle="tab"
                                    data-bs-target="#tab-email-login" type="button" role="tab"
                                    aria-controls="tab-email-login" aria-selected="false">
                                    Reset with Email
                                </button>
                            </li>
                        </ul>

                        <!-- Tab Content -->
                        <div class="tab-content" id="loginTabsContent">
                            <!-- Phone Login Tab -->
                            <div class="tab-pane fade {{ session('active_tab', 'phone') === 'phone' ? 'show active' : '' }}" id="tab-phone-login" role="tabpanel">
                                <form method="POST" action="{{ url('/resetpasswordpost') }}">
                                    @csrf
                                    <div class="mb-3">
                                        <input type="tel" class="form-control" name="login" placeholder="Phone Number"
                                            maxlength="10" pattern="[0-9]{10}" required value="{{ old('login') }}" autofocus>
                                        @error('login')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="mb-4">
                                        <input type="password" class="form-control" name="password" placeholder="New Password" required>
                                        @error('password')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="mb-4">
                                        <input type="password" class="form-control" name="repassword" placeholder="Re-enter Password" required>
                                        @error('repassword')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <button type="submit" class="btn btn-danger w-100 py-2">Reset Password</button>
                                </form>
                            </div>

                            <!-- Email Login Tab -->
                            <div class="tab-pane fade {{ session('active_tab') === 'email' ? 'show active' : '' }}" id="tab-email-login" role="tabpanel">
                                <form method="POST" action="{{ url('/resetpasswordpost') }}">
                                    @csrf
                                    <div class="mb-3">
                                        <input type="email" class="form-control" autofocus name="login" placeholder="Email Address" required value="{{ old('login') }}">
                                        @error('login')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="mb-4">
                                        <input type="password" class="form-control" name="password" placeholder="New Password" required>
                                        @error('password')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="mb-4">
                                        <input type="password" class="form-control" name="repassword" placeholder="Re-enter Password" required>
                                        @error('repassword')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <button type="submit" class="btn btn-danger w-100 py-2">Reset Password</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer text-end">
                        {{-- <span class="text-muted">Don't have an account?</span> --}}
                        <a href="{{ url('/') }}" class="ms-2 text-decoration-none text-primary fw-semibold">
                             
                            Login
                        </a>
                       <span class="text-muted ms-2 fw-semibold">|</span> 
                        <a href="{{ url('/showregister') }}" class="ms-2 text-decoration-none text-primary fw-semibold">
                             
                            Create New Account
                        </a>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>