
<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5 col-lg-4">
            <div class="card shadow-lg">
                <!-- Card Header -->
                <div class="card-header text-center">
                    <div class="d-flex align-items-center justify-content-center mb-3">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Bhumis Logo" class="img-fluid" style="max-width: 5vw;">
                    </div>
                    <h3 class="fw-bold text-dark">Reset Password</h3>
                </div>

                <!-- Card Body -->
                <div class="card-body p-4" x-data="{ activeTab: '<?php echo e(session('active_tab', 'phone')); ?>' }">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(Session::get('error')); ?>

                            <button type="button" class="btn-close" @click="$el.remove()" aria-label="Close"></button>
                        </div>
                    <?php elseif(Session::has('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(Session::get('status')); ?>

                            <button type="button" class="btn-close" @click="$el.remove()" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Tab Navigation -->
                    <div class="nav nav-tabs justify-content-around mb-2" role="tablist">
                        <button type="button" class="tab-button nav-link"
                            :class="activeTab === 'phone' ? 'active' : ''"
                            @click="activeTab = 'phone'" role="tab" aria-selected="true">
                            Reset with Phone
                        </button>
                        <button type="button" class="tab-button nav-link"
                            :class="activeTab === 'email' ? 'active' : ''"
                            @click="activeTab = 'email'" role="tab" aria-selected="false">
                            Reset with Email
                        </button>
                    </div>

                    <!-- Tab Content -->
                    <div>
                        <!-- Phone Reset Tab -->
                        <div x-show="activeTab === 'phone'" x-transition role="tabpanel">
                            <form method="POST" action="<?php echo e(url('/resetpasswordpost')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <input type="tel" class="form-control" name="login" placeholder="Phone Number"
                                        maxlength="10" pattern="[0-9]{10}" required value="<?php echo e(old('login')); ?>" autofocus>
                                    <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-4">
                                    <input type="password" class="form-control" name="password" placeholder="New Password" required>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-4">
                                    <input type="password" class="form-control" name="repassword" placeholder="Re-enter Password" required>
                                    <?php $__errorArgs = ['repassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="submit" class="btn btn-danger w-100 py-2">Reset Password</button>
                            </form>
                        </div>

                        <!-- Email Reset Tab -->
                        <div x-show="activeTab === 'email'" x-transition role="tabpanel">
                            <form method="POST" action="<?php echo e(url('/resetpasswordpost')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <input type="email" class="form-control" name="login" placeholder="Email Address"
                                        required value="<?php echo e(old('login')); ?>">
                                    <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-4">
                                    <input type="password" class="form-control" name="password" placeholder="New Password" required>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-4">
                                    <input type="password" class="form-control" name="repassword" placeholder="Re-enter Password" required>
                                    <?php $__errorArgs = ['repassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="submit" class="btn btn-danger w-100 py-2">Reset Password</button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Card Footer -->
                <div class="card-footer text-end">
                    <a href="<?php echo e(url('/')); ?>" class="ms-2 text-decoration-none text-primary fw-semibold">Login</a>
                    <span class="text-muted ms-2 fw-semibold">|</span>
                    <a href="<?php echo e(url('/showregister')); ?>" class="ms-2 text-decoration-none text-primary fw-semibold">Create New Account</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views\auth\resetpassword.blade.php ENDPATH**/ ?>