

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-semibold">Notifications</h4>
        <?php if($notifications->count() > 0): ?>
            <form action="<?php echo e(route('notifications.read_all')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-outline-primary btn-sm">Mark All as Read</button>
            </form>
        <?php endif; ?>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3 shadow-sm border <?php if(!$notification->is_read): ?> border-warning <?php endif; ?>">
            <div class="card-body d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="fw-bold mb-1"><?php echo e($notification->title); ?></h6>
                    <p class="mb-2 text-muted"><?php echo e($notification->message); ?></p>
                    <?php if($notification->order_id): ?>
                        <a href="<?php echo e(route('orders.show', $notification->order_id)); ?>" class="btn btn-sm btn-outline-warning">
                            View
                        </a>
                    <?php endif; ?>
                </div>

                <div class="text-end">
                    <small class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></small><br>
                    <?php if(!$notification->is_read): ?>
                        <a href="<?php echo e(route('notifications.read', $notification->id)); ?>" class="btn btn-sm btn-success mt-1">
                            Mark as Read
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-info">
            No notifications yet.
        </div>
    <?php endif; ?>


    <div class="d-flex justify-content-center mt-4">
        <?php echo e($notifications->links('pagination::bootstrap-5')); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\btms\resources\views\notifications\index.blade.php ENDPATH**/ ?>