<!-- Trigger Button -->


<!-- Modal -->
<div class="modal fade" id="assignModal<?php echo e($order->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <form method="POST" action="<?php echo e(route('orders.assign', $order->id)); ?>">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Assign Order #<?php echo e($order->order_number); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <label for="assignedto" class="form-label">Select Tailor</label>
                    <select name="assignedto" id="assignedto" class="form-select">
                        <?php $__currentLoopData = $tailors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tailor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tailor->id); ?>"><?php echo e($tailor->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="modal-footer">
                    <button type="sumbit" class="btn btn-sm btn-danger w-100">Assign</button>
                </div>
            </div>
        </form>
    </div>
</div><?php /**PATH D:\btms\resources\views\orders\assign.blade.php ENDPATH**/ ?>