<!-- resources/views/components/metric-card.blade.php -->
<div class="card shadow-sm mb-3" id="card-dashboard">
    <div class="card-body">
        <h6 class="text-muted"><?php echo e($title); ?></h6>
        <h3 class="fw-bold mb-0"><?php echo e($value); ?></h3>
        <?php if($note): ?>
            <small class="text-success"><?php echo e($note); ?></small>
        <?php endif; ?>
    </div>
</div><?php /**PATH D:\btms\resources\views\components\metric-card.blade.php ENDPATH**/ ?>