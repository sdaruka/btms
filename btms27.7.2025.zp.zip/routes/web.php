<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\UserController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\NotificationController;

// 🟢 Guest Routes (unauthenticated)
Route::middleware('guest')->group(function () {
    Route::get('/', fn() => view('auth.login'))->name('login.view');
    Route::get('/showregister', [AuthController::class, 'showRegister']);
    Route::post('/register', [AuthController::class, 'register'])->name('register');
    Route::post('/login', [AuthController::class, 'login'])->name('login');
    Route::get('/resetpassword', [AuthController::class, 'resetPassword']);
    Route::post('/resetpasswordpost', [AuthController::class, 'resetPasswordPost'])->name('resetpassword.post');
});

// 🔐 Authenticated Routes
Route::middleware(['check.auth'])->group(function () {
    // Logout (must be POST for CSRF safety)
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');

    // Profile
    Route::prefix('profile')->group(function () {
        Route::get('/{user}', [UserController::class, 'showProfile'])->name('profile.show');
        Route::get('/edit/{id}', [UserController::class, 'edit'])->name('profile.edit');
        Route::post('/update/{id}', [UserController::class, 'update'])->name('profile.update');
    });

    // Users
    Route::prefix('users')->group(function () {
        Route::get('/', [UserController::class, 'index'])->name('users.index');
        Route::get('/create', [UserController::class, 'create'])->name('users.create');
        Route::post('/store', [UserController::class, 'store'])->name('users.store');
        Route::get('/{id}/edit', [UserController::class, 'edit'])->name('users.edit');
        Route::post('/{id}/update', [UserController::class, 'update'])->name('users.update');
        Route::delete('/{id}', [UserController::class, 'destroy'])->name('users.destroy');
        
    });
Route::post('/customer', [UserController::class, 'storeCustomer']);
    // Products
    Route::prefix('products')->group(function () {
        Route::get('/', [ProductController::class, 'index'])->name('products.index');
        Route::get('/create', [ProductController::class, 'create'])->name('products.create');
        Route::post('/store', [ProductController::class, 'store'])->name('products.store');
        Route::get('/{product}', [ProductController::class, 'show'])->name('products.show');
        Route::get('/{product}/edit', [ProductController::class, 'edit'])->name('products.edit');
        Route::post('/{product}/update', [ProductController::class, 'update'])->name('products.update');
        Route::delete('/{product}', [ProductController::class, 'destroy'])->name('products.destroy');
    });

    // Orders
    Route::prefix('orders')->group(function () {
        Route::get('/', [OrderController::class, 'index'])->name('orders.index');
        Route::get('/create', [OrderController::class, 'create'])->name('orders.create');
        Route::post('/store', [OrderController::class, 'store'])->name('orders.store');
        Route::get('/{order}', [OrderController::class, 'show'])->name('orders.show');
        Route::get('/{order}/print', [OrderController::class, 'print'])->name('orders.print');
        Route::get('/{order}/edit', [OrderController::class, 'edit'])->name('orders.edit');
        Route::post('/{order}/update', [OrderController::class, 'update'])->name('orders.update');
        Route::delete('/{order}', [OrderController::class, 'destroy'])->name('orders.destroy');
        Route::patch('/{order}/status', [OrderController::class, 'updateStatus'])->name('orders.updateStatus');
        Route::post('/{order}/assign', [OrderController::class, 'assignOrder'])->name('orders.assign');

        Route::get('/measurements/{user}', [OrderController::class, 'loadPreviousMeasurements'])
            ->missing(fn() => response()->json(['error' => 'User not found'], 404));
    });

    // Notifications
    Route::prefix('notifications')->group(function () {
        Route::get('/', [NotificationController::class, 'index'])->name('notifications');
        Route::get('/read/{id}', [NotificationController::class, 'markAsRead'])->name('notifications.read');
        Route::post('/read-all', [NotificationController::class, 'markAllAsRead'])->name('notifications.read_all');
    });
});