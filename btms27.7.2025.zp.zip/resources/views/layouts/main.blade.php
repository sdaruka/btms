<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="description" content="Tailor order and customer management made easy.">
    <meta name="author" content="Bhumis Tailor System">
    <meta property="og:title" content="Bhumis Tailor Management System">
    <meta property="og:description" content="Streamline your tailoring business with smart order workflows.">
    <meta property="og:type" content="website">

    <title>@yield('title')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('images/logo.png') }}">
    <link rel="apple-touch-icon" href="{{ asset('images/logo.png') }}">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    
    <link rel="manifest" href="{{ asset('/manifest.json') }}">
    <meta name="theme-color" content="#ffc107">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

</head>

<body>
    <div id="installPopup" style="display:none; position:fixed; bottom:2rem; left:2rem; background:#ffc107; padding:1rem; border-radius:8px; box-shadow:0 4px 12px rgba(0,0,0,0.2); z-index:9999;">
        <p>Install BTMS for fast access and offline support.</p>
        <button id="installButton" class="btn btn-dark btn-sm me-2">Install</button>
        <button id="cancelInstallButton" class="btn btn-outline-dark btn-sm">Cancel</button>
    </div>

    <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>
    
    <div class="d-flex">
        @unless (Request::is('/') || Request::is('showregister'))
            @include('layouts.sidebar')
            <div class="flex-grow-1">
            @include('layouts.top-nav')
        @endunless

        <main class="container-fluid p-3 bg-light">
            @yield('content')
        </main>
        </div>
    </div>
    
<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('sidebarToggle', () => ({
            sidebarOpen: false,
            toggle() {
                this.sidebarOpen = !this.sidebarOpen
            }
        }))
    });

    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('active');
        document.getElementById('overlay').classList.toggle('active');
    }

    document.addEventListener('DOMContentLoaded', function () {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        const installPopup = document.getElementById('installPopup');
        const installButton = document.getElementById('installButton');
        const cancelInstallButton = document.getElementById('cancelInstallButton');

        // Close sidebar when clicking outside
        if (overlay) {
            overlay.addEventListener('click', function () {
                if (sidebar) sidebar.classList.remove('active');
                overlay.classList.remove('active');
            });
        }

        // Close sidebar on escape key
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                if (sidebar) sidebar.classList.remove('active');
                if (overlay) overlay.classList.remove('active');
            }
        });

        // --- PWA Installation Logic ---
        let deferredPrompt; // Global variable to store the beforeinstallprompt event

        // Service Worker Registration
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/btms/sw.js')
                .then(registration => {
                    console.log('Service Worker registered successfully:', registration);
                })
                .catch(error => {
                    console.error('Service Worker registration failed:', error);
                });
        }

        // Listen for the beforeinstallprompt event
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault(); // Prevent the default mini-infobar
            deferredPrompt = e; // Stash the event
            console.log('beforeinstallprompt event fired, deferred.');

            // Show your custom install UI
            if (installPopup) {
                installPopup.style.display = 'block';
            }
        });

        // Function to handle custom "Install" button click
        if (installButton) {
            installButton.addEventListener('click', async () => {
                if (deferredPrompt) {
                    if (installPopup) {
                        installPopup.style.display = 'none'; // Hide custom popup
                    }

                    deferredPrompt.prompt(); // Show native installation prompt

                    const { outcome } = await deferredPrompt.userChoice;
                    console.log(`User response to the A2HS prompt: ${outcome}`);

                    deferredPrompt = null; // Clear the deferredPrompt

                    if (outcome === 'accepted') {
                        console.log('User accepted the A2HS prompt');
                    } else {
                        console.log('User dismissed the A2HS prompt');
                    }
                } else {
                    console.log('Deferred prompt not available. Maybe already installed or criteria not met.');
                }
            });
        }

        // Function to handle custom "Cancel" button click
        if (cancelInstallButton) {
            cancelInstallButton.addEventListener('click', () => {
                if (installPopup) {
                    installPopup.style.display = 'none'; // Hide custom popup
                }
                console.log('Install prompt popup closed by user.');
                // Optionally, store a flag in localStorage to avoid showing it too frequently
            });
        }

        // Listen for the appinstalled event
        window.addEventListener('appinstalled', () => {
            console.log('PWA was installed!');
            if (installPopup) {
                installPopup.style.display = 'none'; // Ensure custom popup is hidden
            }
            deferredPrompt = null; // Just in case
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>