@extends('layouts.main')
@section('title', 'New Order')
@section('content')

<!-- Alpine Scope -->
<div x-data="orderForm(false)" x-init="init()">
    <form 
        action="{{ route('orders.store') }}" 
        method="POST" 
        enctype="multipart/form-data" 
        x-ref="orderForm" 
        @submit.prevent="submitForm"
    >
        @csrf

        <div class="container">
            <h2 class="mb-4">Place New Order</h2>

            {{-- Error Messages --}}
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $msg)
                            <li>{{ $msg }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @if (session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif

            @if (session('status'))
                <div class="alert alert-info">{{ session('status') }}</div>
            @endif

            {{-- Partials --}}
            @include('orders.partial.customer')
            @include('orders.partial.items')
            @include('products.product-modal')
            @include('orders.partial.invoice')

            <button type="submit" class="btn btn-danger w-100 mt-4">
                <i class="fa fa-save me-2"></i> Place Order
            </button>
        </div>
    </form>

    {{-- Customer Modal --}}
    <div x-show="showModal" x-transition.opacity @keydown.escape.window="showModal = false"
         class="modal-backdrop"
         style="position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.5); z-index: 1050;">
        <div class="modal-content" style="...">
            <h5 class="mb-3">Add New Customer</h5>

            <input type="text" x-model="newCustomer.name" class="form-control mb-2" placeholder="Customer Name">
            <input type="text" x-model="newCustomer.phone" class="form-control mb-2" placeholder="Phone">

            <template x-if="customerErrorMessage">
                <div class="text-danger small mt-2" x-text="customerErrorMessage"></div>
            </template>

            <div class="d-flex justify-content-end">
                <button type="button" class="btn btn-secondary me-2" @click="showModal = false">Cancel</button>
                <button type="button" class="btn btn-primary" @click="createCustomer">Save</button>
            </div>
        </div>
    </div>

    {{-- Image Preview --}}
    <img x-show="hoveredPreview" :src="hoveredPreview" class="thumb-preview" @mousemove="..." @mouseleave="hoveredPreview = null">

    {{-- Alpine Init --}}
    @include('orders.partial.alpine')
</div>
@endsection