<!-- resources/views/layouts/main.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Prevent caching -->
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">

    <!-- Force latest IE rendering engine -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- SEO & social preview optimization -->
    <meta name="description" content="Tailor order and customer management made easy.">
    <meta name="author" content="Bhumis Tailor System">
    <meta property="og:title" content="Bhumis Tailor Management System">
    <meta property="og:description" content="Streamline your tailoring business with smart order workflows.">
    <meta property="og:type" content="website">

    <title>@yield('title')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('images/logo.png') }}">
    <link rel="apple-touch-icon" href="{{ asset('images/logo.png') }}">
    {{-- <link rel="stylesheet" href="{{ asset('css/style.css') }}"> --}}
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
   
<link rel="manifest" href="{{ asset('/manifest.json') }}">
<meta name="theme-color" content="#ffc107">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

</head>

<body>
    <div id="installPopup" style="display:none; position:fixed; bottom:2rem; left:2rem; background:#ffc107; padding:1rem; border-radius:8px; box-shadow:0 4px 12px rgba(0,0,0,0.2); z-index:9999;">
  <p>Install BTMS for fast access and offline support.</p>
  <button class="btn btn-dark btn-sm me-2" onclick="installApp()">Install</button>
  <button class="btn btn-outline-dark btn-sm" onclick="closePopup()">Cancel</button>
</div>

    <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>
    
    <div class="d-flex">
        <!-- Sidebar -->

        @unless (Request::is('/') || Request::is('showregister'))
            @include('layouts.sidebar')
            <div class="flex-grow-1">
            <!-- Topbar -->
            @include('layouts.top-nav')
        @endunless

        <!-- Sidebar -->

        <!-- Main Content -->
        

            <main class="container-fluid p-3 bg-light">
                @yield('content')
            </main>
        </div>
    </div>
    <script>
    const safeConfig = typeof config === 'string' ? config : JSON.stringify(config);
element.setAttribute('data-bs-config', safeConfig);
</script>
{{-- <script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('sidebarToggle', () => ({
            sidebarOpen: false,
            toggle() {
                this.sidebarOpen = !this.sidebarOpen
            }
        }))
    })
</script> --}}
    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
            document.getElementById('overlay').classList.toggle('active');
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
     
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

<script>
//   if ('serviceWorker' in navigator) {
//     navigator.serviceWorker.register('/sw.js').then(() => {
//     //   console.log('Service Worker registered');
//     });
//   }
</script>
<script>
//   import { Workbox } from 'https://storage.googleapis.com/workbox-cdn/releases/6.5.4/workbox-window.prod.mjs';

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/btms/sw-workbox.js');
    console.log('Service Worker registered');
  }
</script>

<script>
    let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  document.getElementById('installPopup').style.display = 'block';
});

function installApp() {
  deferredPrompt.prompt();
  deferredPrompt.userChoice.then(() => {
    document.getElementById('installPopup').style.display = 'none';
    deferredPrompt = null;
  });
}

function closePopup() {
  document.getElementById('installPopup').style.display = 'none';
}
</script>
{{-- <script>
    
    document.getElementById('installBtn').addEventListener('click', async () => {
        if (!deferredPrompt) return;

        deferredPrompt.prompt(); // Show browser install dialog

        const { outcome } = await deferredPrompt.userChoice;
        console.log(`User response: ${outcome}`);

        // Hide popup after interaction
        document.getElementById('installPopup').style.display = 'none';
        deferredPrompt = null;
    });
</script> --}}


</body>

</html>
