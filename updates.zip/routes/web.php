<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\auth\authcontroller;
use App\Http\Controllers\auth\UserController;
use App\Http\Middleware\RedirectIfNotAuthenticated;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\NotificationController;

Route::get('/', function () {
    return view('auth.login');
});

Route::get('/showregister', [authcontroller::class, 'showregister']);
Route::post('/register', [authcontroller::class, 'register'])->name('register');
Route::post('/login', [authcontroller::class, 'login'])->name('login');
Route::get('/resetpassword', [authcontroller::class, 'resetpassword']);
Route::post('/resetpasswordpost', [authcontroller::class, 'resetPasswordpost'])->name('resetpassword');

Route::get('/logout', function () {
    auth()->logout();
    return redirect('/');
})->name('logout');


Route::middleware(['check.auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');
    Route::get('/profile/{user}', [UserController::class, 'showProfile'])->name('profile.show');
    Route::get('/profile/edit/{id}', [UserController::class, 'edit'])->name('profile.edit');
    Route::post('/profile/update/{id}', [UserController::class, 'update'])->name('profile.update');
    Route::get('/users', [UserController::class, 'index'])->name('users.index');
    Route::get('/users/create', [UserController::class, 'create'])->name('users.create');
    Route::post('/users/store', [UserController::class, 'store'])->name('users.store');
    Route::get('/users/{id}/edit', [UserController::class, 'edit'])->name('users.edit');
    Route::post('/users/{id}/update', [UserController::class, 'update'])->name('users.update');
    Route::delete('/users/{id}', [UserController::class, 'destroy'])->name('users.destroy');
    Route::post('/customer', [UserController::class, 'storeCustomer']);
    
    // products routes
    Route::get('/products', [ProductController::class, 'index'])->name('products.index');
    Route::get('/products/create', [ProductController::class, 'create'])->name('products.create');
    Route::post('/products/store', [ProductController::class, 'store'])->name('products.store');
    Route::get('/products/{product}', [ProductController::class, 'show'])->name('products.show');
    Route::get('/products/{product}/edit', [ProductController::class, 'edit'])->name('products.edit');
    Route::post('/products/{product}/update', [ProductController::class, 'update'])->name('products.update');
    Route::delete('/products/{product}', [ProductController::class, 'destroy'])->name('products.destroy');
      
    
    // Orders routes
    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/create', [OrderController::class, 'create'])->name('orders.create');
    Route::post('/orders/store', [OrderController::class, 'store'])->name('orders.store');
    Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');
    Route::get('/orders/{order}/print', [OrderController::class, 'print'])->name('orders.print');
    Route::get('/orders/{order}/edit', [OrderController::class, 'edit'])->name('orders.edit');
    Route::post('/orders/{order}/update', [OrderController::class, 'update'])->name('orders.update');
    Route::delete('/orders/{order}', [OrderController::class, 'destroy'])->name('orders.destroy');
    Route::patch('/orders/{order}/status', [OrderController::class, 'updateStatus'])->name('orders.updateStatus');
    // Route::get('/orders/{order}/assign', [OrderController::class, 'assignOrder'])->name('orders.assign');
    Route::post('/orders/{order}/assign', [OrderController::class, 'assignOrder'])->name('orders.assign');
    Route::get('/orders/measurements/{user}', [OrderController::class, 'loadPreviousMeasurements'])
    ->missing(function () {
        return response()->json(['error' => 'User not found'], 404);
    });


    // Notification routes
    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications');
    Route::get('/notifications/read/{id}', [NotificationController::class, 'markAsRead'])->name('notifications.read');
    Route::post('/notifications/read-all', [NotificationController::class, 'markAllAsRead'])->name('notifications.read_all');

});
