@extends('layouts.main')

@section('content')
    <style>
       
    </style>

    <div class="container">
        <div class="row mb-4 g-2 align-items-center">
            <div class="col-12 col-md-4">
                <h2 class="fw-bold mb-0">Manage Users</h2>
            </div>
            @if (Session::has('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    {{ Session::get('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif
            <div class="col-12 col-md-6">
                <form action="{{ route('users.index') }}" method="GET" class="d-flex">
                    <input type="text" name="search" value="{{ request('search') }}" class="form-control me-2"
                        placeholder="Search by name or phone">
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-search"></i>
                    </button>
                </form>
            </div>
            <div class="col-12 col-md-2 text-md-end">
                <a href="{{ route('users.create') }}" class="btn btn-warning w-100 w-md-auto">
                    <i class="fa fa-user-plus me-1"></i> Add User
                </a>
            </div>
        </div>

        @if ($users->count())
            <div class="table-responsive-sm">
                <table class="table table-striped table-bordered align-middle shadow-sm w-100">
                    <thead>
                        <tr class="bg-dark text-white">
                            <th>#</th>
                            <th>Profile</th>
                            <th>Name</th>
                            {{-- <th>Email</th> --}}
                            {{-- <th>Phone</th> --}}
                            <th>Role</th>
                            <th>Status</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $user)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>
                                    <img src="{{ $user->profile_picture ? asset($user->profile_picture) : asset('images/default-user.png') }}"
                                        class="rounded-circle shadow" width="40" height="40" alt="avatar">
                                </td>
                                <td class="d-flex d-col">{{ $user->name }} <br>
                                    {{ $user->phone }}
                                </td>
                                {{-- <td>{{ $user->email }}</td> --}}
                                {{-- <td>{{ $user->phone }}</td> --}}
                                <td>
                                    <span class="badge bg-secondary">{{ ucfirst($user->role) }}</span>
                                </td>
                                <td>
                                    @if ($user->is_active)
                                        <span class="badge bg-success">Active</span>
                                    @else
                                        <span class="badge bg-danger">Inactive</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    <div class="dropdown">
                                        <button class="btn btn-light border-0" type="button" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="fa-solid fa-ellipsis-vertical"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li>
                                                <a class="dropdown-item"
                                                    href="{{ route('profile.show', ['user' => $user->id]) }}">
                                                    <i class="fa fa-eye me-2 text-info"></i> View
                                                </a>
                                                
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="{{ route('profile.edit', $user->id) }}">
                                                    <i class="fa fa-edit me-2 text-warning"></i> Edit
                                                </a>
                                            </li>
                                            <li>
                                                {{-- @if ($user->role == 'admin') --}}
                                                    <form action="{{ route('users.destroy', $user->id) }}" method="POST"
                                                        onsubmit="return confirm('Are you sure?')">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="dropdown-item text-danger">
                                                            <i class="fa fa-trash me-2"></i> Delete
                                                        </button>
                                                    </form>
                                                {{-- @endif --}}
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                {{ $users->links('pagination::bootstrap-5') }}
            </div>
        @else
            <div class="alert alert-info">No users found.</div>
        @endif
    </div>
@endsection
