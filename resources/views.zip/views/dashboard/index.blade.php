<!-- resources/views/dashboard/index.blade.php -->
